#include <stdio.h>

int isPrime(int n) {
    if (n <= 1) {
        return 0;
    }
    int i;
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

void printPrimes(int start, int end) {
    printf("Primes: ");
    for (int i = start; i <= end; i++) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int countPrimes(int start, int end) {
    int count = 0;
    for (int i = start; i <= end; i++) {
        if (isPrime(i)) {
            count++;
        }
    }
    return count;
}

int main() {
    int start, end;
    
    do {
        printf("Enter range (start end): ");
        scanf("%d %d", &start, &end);
        
        if (start >= end) {
            printf("Invalid range! 'start' must be less than 'end'. Try again.\n");
        }
    } while (start >= end);
    
    printPrimes(start, end);
    int total = countPrimes(start, end);
    printf("Total primes found: %d\n", total);
    
    return 0;
}
