#include <stdio.h>

int findTotal(int marks[], int size) {
    int total = 0;
    int i;
    for (i = 0; i < size; i++) {
        total += marks[i];
    }
    return total;
}

float findPercentage(int total, int size) {
    return (float)total / size;
}

char findGrade(float percentage) {
    if (percentage >= 80.0) {
        return 'A';
    } else if (percentage >= 60.0) {
        return 'B';
    } else if (percentage >= 40.0) {
        return 'C';
    } else {
        return 'F';
    }
}

int findMax(int marks[], int size) {
    int max = marks[0];
    int i;
    for (i = 1; i < size; i++) {
        if (marks[i] > max) {
            max = marks[i];
        }
    }
    return max;
}

int findMin(int marks[], int size) {
    int min = marks[0];
    int i;
    for (i = 1; i < size; i++) {
        if (marks[i] < min) {
            min = marks[i];
        }
    }
    return min;
}

void printReport(int marks[], int size) {
    int total = findTotal(marks, size);
    float percentage = findPercentage(total, size);
    char grade = findGrade(percentage);
    int highest = findMax(marks, size);
    int lowest = findMin(marks, size);
    
    printf("Total: %d\n", total);
    printf("Percentage: %.2f%%\n", percentage);
    printf("Grade: %c\n", grade);
    printf("Highest: %d\n", highest);
    printf("Lowest: %d\n", lowest);
}

int main() {
    int size = 5;
    int marks[5];
    int i;
    
    printf("Enter 5 Subject's marks:\n ");
    for (i = 0; i < size; i++) {
        scanf("%d", &marks[i]);
    }
    
    printReport(marks, size);
    
    return 0;
}
