#include <stdio.h>
long factorial(int n) {
    long fact = 1;
    int i;
    for (i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}
int reverseNumber(int n) {
    int rev = 0;
    int rem;
    while (n > 0) {
        rem = n % 10;
        rev = rev * 10 + rem;
        n /= 10;
    }
    return rev;
}
int isPalindrome(int n) {
    if (n == reverseNumber(n)) {
        return 1;
    }
    return 0;
}

int sumOfDigits(int n) {
    int sum = 0;
    int rem;
    while (n > 0) {
        rem = n % 10;
        sum += rem;
        n /= 10;
    }
    return sum;
}
void printFibonacci(int terms) {
    long t1 = 0;
    long t2 = 1;
    long nextTerm;
    int i;
    
    if (terms <= 0) {
        return;
    }   
    for (i = 1; i <= terms; i++) {
        printf("%ld ", t1);
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
    printf("\n");
}
int main() {
    int choice;
    int n;
    
    while (1) {
        printf("\nMenu:\n");
        printf("1. Factorial\n");
        printf("2. Reverse Number\n");
        printf("3. Check Palindrome\n");
        printf("4. Sum of Digits\n");
        printf("5. Fibonacci Series\n");
        printf("6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        
        if (choice == 6) {
            break;
        }
        
        if (choice >= 1 && choice <= 4) {
            printf("Enter number: ");
            scanf("%d", &n);
        } else if (choice == 5) {
            printf("Enter number of terms: ");
            scanf("%d", &n);
        }
        
        if (choice == 1) {
            printf("Factorial: %ld\n", factorial(n));
        } else if (choice == 2) {
            printf("Reversed number: %d\n", reverseNumber(n));
        } else if (choice == 3) {
            if (isPalindrome(n)) {
                printf("%d is a palindrome.\n", n);
            } else {
                printf("%d is not a palindrome.\n", n);
            }
        } else if (choice == 4) {
            printf("Sum of digits: %d\n", sumOfDigits(n));
        } else if (choice == 5) {
            printf("Fibonacci Series: ");
            printFibonacci(n);
        } else {
            printf("Invalid choice! Try again.\n");
        }
    }
    
    return 0;
}
