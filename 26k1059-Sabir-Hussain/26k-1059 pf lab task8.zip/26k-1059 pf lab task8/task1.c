#include <stdio.h>

float calculateBill(int units) {
    float bill = 0.0;
    
    if (units <= 100) {
        bill = units * 10.0;
    } else if (units <= 200) {
        bill = (100 * 10.0) + ((units - 100) * 15.0);
    } else {
        bill = (100 * 10.0) + (100 * 15.0) + ((units - 200) * 20.0);
    }
    
    bill += 150.0;
    
    return bill;
}

void printBill(int units, float bill) {
    printf("Units Consumed: %d\n", units);
    printf("Total Bill: Rs. %.2f\n", bill);
}

int main() {
    int units,i;
    
    for (i = 1; i <= 3; i++) {
        printf("Customer %d:\n", i);
        printf("Enter units: ");
        scanf("%d", &units);
        
        float bill = calculateBill(units);
        printBill(units, bill);
        printf("\n");
    }
    
    return 0;
}
